﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;
using SafeGuard;

namespace Authenticator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        

        private void ToggleButton_Checked(object sender, RoutedEventArgs e)
        {
            foreach (var child in ToggleButtonContainer.Children)
            {
                if (child is ToggleButton toggleButton && toggleButton != sender)
                {
                    toggleButton.IsChecked = false;
                }
            }
        }

        private void ToggleButton_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (sender is ToggleButton toggleButton && toggleButton.IsChecked == true && e.LeftButton == MouseButtonState.Pressed)
            {
                e.Handled = true;
            }
        }

        private void drag_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }

        private void applicationMinimize_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }
        private void applicationClose_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}