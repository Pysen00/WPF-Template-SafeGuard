﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SafeGuard.src.frontend.userframes
{
    /// <summary>
    /// Interaction logic for GuardFrame.xaml
    /// </summary>
    public partial class GuardFrame : UserControl
    {
        public GuardFrame()
        {
            InitializeComponent();
            virusGuard.IsChecked = true;
        }

        private void ToggleButton_PreviewMouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (sender is ToggleButton toggleButton && toggleButton.IsChecked == true && e.LeftButton == System.Windows.Input.MouseButtonState.Pressed)
            {
                e.Handled = true;
            }
        }

        private void ToggleButton_Checked(object sender, RoutedEventArgs e)
        {
            foreach (var child in toggleButtonContainer.Children)
            {
                if (child is ToggleButton toggleButton && toggleButton != sender)
                {
                    toggleButton.IsChecked = false;
                }
            }


            ToggleButton toggledButton = sender as ToggleButton;

            double newPosition = 0;
            double newWidth = 0;
            switch (toggledButton.Name)
            {
                case "virusGuard":
                    newPosition = 0;
                    newWidth = 101;
                    break;
                case "extraProtection":
                    newPosition = 131;
                    newWidth = 120;
                    break;
                case "virusScan":
                    newPosition = 289;
                    newWidth = 86;
                    break;
                case "ransomwareGuard":
                    newPosition = 413;
                    newWidth = 150;
                    break;
                default:
                    newPosition = 0;
                    newWidth = 101;
                    break;
            }

            checkedIndicator.BeginAnimation(MarginProperty, new ThicknessAnimation
            {
                From = checkedIndicator.Margin,
                To = new Thickness(newPosition, 0, 0, 0),
                Duration = TimeSpan.FromSeconds(0.3)
            });

            checkedIndicator.BeginAnimation(WidthProperty, new DoubleAnimation
            {
                From = checkedIndicator.Width,
                To = newWidth,
                Duration = TimeSpan.FromSeconds(0.3)
            });
        }



    }
}
