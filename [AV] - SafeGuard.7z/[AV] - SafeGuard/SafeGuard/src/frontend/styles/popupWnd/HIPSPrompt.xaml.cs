﻿using System.Windows;
using System.Windows.Input;

namespace SafeGuard.src.frontend.styles.popupWnd
{
    /// <summary>
    /// Interaction logic for HIPSPrompt.xaml
    /// </summary>
    public partial class HIPSPrompt : Window
    {
        public HIPSPrompt(string title, string zone, string message, string connection)
        {
            InitializeComponent();
            titleHIPS.Text = title;
            zoneHIPS.Text = zone;
            messageHIPS.Text = message;
            connectionHIPS.Text = connection;
        }

        private void closeHIPS(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void drag_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }
    }
}
